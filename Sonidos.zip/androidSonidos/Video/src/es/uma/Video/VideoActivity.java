package es.uma.Video;

import java.io.File;

import android.app.Activity;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.os.Environment;
import android.widget.MediaController;
import android.widget.VideoView;

public class VideoActivity extends Activity {
    /** Called when the activity is first created. */
    
    private VideoView miVideo;
    private MediaController mc;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        getWindow().setFormat(PixelFormat.TRANSLUCENT);
        setContentView(R.layout.main);
        
        
        miVideo = (VideoView) findViewById(R.id.video);

        File pathToTest= new File (Environment.getExternalStorageDirectory(),"test.mp4");
        miVideo.setVideoPath(pathToTest.getAbsolutePath());
        
        mc = new MediaController(this);
        mc.setMediaPlayer(miVideo);
        miVideo.setMediaController(mc);
        miVideo.requestFocus();
        
    }
}