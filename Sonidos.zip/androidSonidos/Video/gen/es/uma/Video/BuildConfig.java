/** Automatically generated file. DO NOT MODIFY */
package es.uma.Video;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}