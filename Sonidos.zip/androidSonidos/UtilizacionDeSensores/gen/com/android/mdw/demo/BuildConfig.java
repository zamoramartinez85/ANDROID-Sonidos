/** Automatically generated file. DO NOT MODIFY */
package com.android.mdw.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}